import express from 'express';
import sqlite3 from 'sqlite3';
import cors from 'cors';
import bcrypt from 'bcrypt';

const app = express();
const PORT = process.env.PORT || 5000;

// Enable CORS middleware
app.use(cors());

// Connect to SQLite database for users
const usersDB = new sqlite3.Database('./server/database/users.db');
const reservationsDB = new sqlite3.Database('./server/database/reservations.db');

// Create a table for users if it doesn't exist
usersDB.run(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    password TEXT
  )
`);

// Create a table for reservations if it doesn't exist
reservationsDB.run(`
  CREATE TABLE IF NOT EXISTS reservations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    dateTime TEXT,
    mobileNumber TEXT,
    numberOfPeople INTEGER,
    userId INTEGER,
    FOREIGN KEY (userId) REFERENCES users(id)
  )
`);

// Middleware to parse JSON in the request body
app.use(express.json());

// Signup endpoint
app.post('/api/signup', async (req, res) => {
  const { username, password } = req.body;

  // Hash the password
  const hashedPassword = await bcrypt.hash(password, 10);

  // Insert user into the database
  const stmt = usersDB.prepare('INSERT INTO users (username, password) VALUES (?, ?)');
  stmt.run(username, hashedPassword, (err) => {
    if (err) {
      console.error('Error creating user:', err);
      res.status(500).json({ message: 'Internal server error' });
    } else {
      res.status(201).json({ message: 'User created successfully' });
    }
  });
  stmt.finalize();
});

// Login endpoint
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  // Retrieve user from the database
  usersDB.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
    if (err) {
      console.error('Error retrieving user:', err);
      res.status(500).json({ message: 'Internal server error' });
    } else if (!user) {
      res.status(401).json({ message: 'Invalid username or password' });
    } else {
      // Compare the provided password with the hashed password from the database
      const passwordMatch = await bcrypt.compare(password, user.password);
      if (passwordMatch) {
        res.status(200).json({ message: 'Login successful' });
      } else {
        res.status(401).json({ message: 'Invalid username or password' });
      }
    }
  });
});

// Reservation endpoint (requires authentication)
app.post('/api/reservations', authenticateUser, (req, res) => {
  const { name, email, dateTime, mobileNumber, numberOfPeople } = req.body;

  // Insert reservation into the database
  const stmt = reservationsDB.prepare('INSERT INTO reservations (name, email, dateTime, mobileNumber, numberOfPeople, userId) VALUES (?, ?, ?, ?, ?, ?)');
  stmt.run(name, email, dateTime, mobileNumber, numberOfPeople, req.user.id, (err) => {
    if (err) {
      console.error('Error saving reservation:', err);
      res.status(500).json({ message: 'Internal server error' });
    } else {
      res.status(201).json({ message: 'Reservation saved successfully' });
    }
  });
  stmt.finalize();
});

// Middleware to authenticate user and add user information to the request object
function authenticateUser(req, res, next) {
  // Implement your authentication logic here
  // For simplicity, you can use a token-based authentication approach
  const authToken = req.headers.authorization;

  // Check if authToken exists
  if (!authToken) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  // Implement your token verification logic (e.g., using a library like jsonwebtoken)
  // For now, let's assume you have a function verifyAuthToken that returns the user ID
  const userId = verifyAuthToken(authToken);

  if (userId) {
    // Add user information to the request object
    req.user = { id: userId };
    next();
  } else {
    return res.status(401).json({ message: 'Unauthorized' });
  }
}

// Function to verify authentication token (example)
function verifyAuthToken(authToken) {
  // Implement your token verification logic (e.g., using jsonwebtoken)
  // Return the user ID if the token is valid, otherwise return null
  return 'exampleUserId';
}

// Close the SQLite databases when the server is stopped
process.on('SIGINT', () => {
  usersDB.close((err) => {
    if (err) {
      console.error('Error closing the users database connection:', err);
    } else {
      console.log('Users database connection closed');
    }
  });

  reservationsDB.close((err) => {
    if (err) {
      console.error('Error closing the reservations database connection:', err);
    } else {
      console.log('Reservations database connection closed');
    }

    process.exit();
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
