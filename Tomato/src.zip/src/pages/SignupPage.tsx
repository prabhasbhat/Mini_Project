import React, { useState } from 'react';
import { useHistory, Link } from 'react-router-dom';
import './SignupPage.css';

const SignupPage = () => {
  const history = useHistory();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Added state variables for error messages
  const [usernameError, setUsernameError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [confirmPasswordError, setConfirmPasswordError] = useState('');

  const handleSignup = async () => {
    setIsSubmitted(true);

    if (!username || !password || password !== confirmPassword) {
      // Validation failed
      if (!username) {
        setUsernameError('Username is required');
      } else {
        setUsernameError('');
      }

      if (!password) {
        setPasswordError('Password is required');
      } else {
        setPasswordError('');
      }

      if (password !== confirmPassword) {
        setConfirmPasswordError('Passwords do not match');
      } else {
        setConfirmPasswordError('');
      }

      return;
    }

    try {
      // Send user data to the server
      const response = await fetch('http://localhost:5000/api/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      if (response.ok) {
        console.log('User successfully signed up!');
        history.push('/'); // Redirect to the homepage after successful signup
      } else {
        console.error('Signup failed');
      }
    } catch (error) {
      console.error('Error during signup:', error);
    }
  };

  return (
    <div className="signup-container">
      <h1>Sign Up</h1>
      <form>
        <label htmlFor="username">Username:</label>
        <input
          type="text"
          id="username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className={isSubmitted && !username ? 'error' : ''}
        />
        <p className="error-message">{usernameError}</p>

        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className={isSubmitted && !password ? 'error' : ''}
        />
        <p className="error-message">{passwordError}</p>

        <label htmlFor="confirmPassword">Confirm Password:</label>
        <input
          type="password"
          id="confirmPassword"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          className={isSubmitted && password !== confirmPassword ? 'error' : ''}
        />
        <p className="error-message">{confirmPasswordError}</p>

        <button type="button" onClick={handleSignup}>
          Sign Up
        </button>

        <p>If already signed up, <Link to="/loginpage">login here</Link>.</p>
      </form>
    </div>
  );
};

export default SignupPage;
