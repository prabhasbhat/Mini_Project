import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import './LoginPage.css';


const LoginPage: React.FC<{ onLogin: () => void }> = ({ onLogin }) => {
  const history = useHistory();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      // Send a POST request to the login endpoint
      const response = await fetch('http://localhost:5000/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      // Check if the login was successful (status code 200)
      if (response.ok) {
        console.log('Login successful!');
        // Perform any additional logic, such as storing tokens
        onLogin();
        // Redirect to the homepage after successful login
        history.push('/homepage');
      } else {
        console.error('Login failed:', response.statusText);
        // Handle failed login (show an error message, redirect, etc.)
        // For demonstration purposes, let's just log the error
      }
    } catch (error) {
      console.error('Error during login:', error);
    }
  };

  return (
    <div className="login-container">
      <h1>Login</h1>
      <form>
        <label htmlFor="username">Username:</label>
        <input
          type="text"
          id="username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />

        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button type="button" onClick={handleLogin}>
          Login
        </button>
      </form>
    </div>
  );
};

export default LoginPage;
