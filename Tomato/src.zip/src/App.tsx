import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faCalendar, faUtensils, faSignInAlt, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';  // Import the LoginPage component
import SignupPage from './pages/SignupPage';
import Reservation from './pages/ReservationPage';
import MenuPage from './pages/Mexicanmenu';
import Indian from './pages/Indianmenu';
import Italian from './pages/Italianmenu';
import Japense from './pages/Japensemenu';
import Chinese from './pages/Chinisemenu';
import American from './pages/Americanmenu';
import DeliveryForm from './pages/DeliveryForm';
import DineInForm from './pages/DineInForm';
import './style.css';
import RestaurantSplashScreen from './pages/RestaurantSplashScreen';

const App: React.FC = () => {
  // State to store user authentication status
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Function to handle successful login
  const handleLogin = () => {
    // Perform login logic (set token, etc.)
    setIsLoggedIn(true);
  };

  // Function to handle logout
  const handleLogout = () => {
    // Perform logout logic (clear token, etc.)
    setIsLoggedIn(false);
  };

  return (
    <Router>
      <div>
        {/* Main content */}
        <Switch>
          <Route path="/" exact component={RestaurantSplashScreen} />
          <Route path="/homepage" component={HomePage} />
          <Route path="/loginpage">
            {/* Pass handleLogin function to LoginPage */}
            <LoginPage onLogin={handleLogin} />
          </Route>
          <Route path="/signup" component={SignupPage} />
          <Route path="/Mexicanmenu" component={MenuPage} />
          <Route path="/Indianmenu" component={Indian} />
          <Route path="/Italianmenu" component={Italian} />
          <Route path="/japensemenu" component={Japense} />
          <Route path="/Chinisemenu" component={Chinese} />
          <Route path="/Americanmenu" component={American} />
          <Route path="/Reservation" component={Reservation} />
          <Route path="/delivery/:id" component={DeliveryForm} />
          <Route path="/dine-in/:id" component={DineInForm} />
          <Redirect from="/" to="/homepage" exact />
        </Switch>

        {/* Bottom Navigation */}
        <div className="bottom-navbar">
          <a href="/homepage">
            <FontAwesomeIcon icon={faHome} />
            Home
          </a>
          <a href="/reservation">
            <FontAwesomeIcon icon={faCalendar} />
            Reservation
          </a>
          <a href='/dine-in/:id'>
            <FontAwesomeIcon icon={faUtensils} />
            DineIn
          </a>
          {/* Show Login, Logout, or Signup based on authentication status */}
          {isLoggedIn ? (
            <>
              <a href="/logout" onClick={handleLogout}>
                <FontAwesomeIcon icon={faSignOutAlt} />
                Logout
              </a>
            </>
          ) : (
            <>
              <a href="/loginpage">
                <FontAwesomeIcon icon={faSignInAlt} />
                Login
              </a>
              <a href="/signup">
                Signup
              </a>
            </>
          )}
        </div>
      </div>
    </Router>
  );
};

export default App;
